// File: contest_3-2_1.js
	        
// Second entry
function yourname_2d_contest_1() {
}

clear_all();
yourname_2d_contest_1();
