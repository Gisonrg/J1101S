// File: contest_3-2_1.js
	        
// Third entry
function yourname_2d_contest_2() {
}

clear_all();
yourname_2d_contest_2();
