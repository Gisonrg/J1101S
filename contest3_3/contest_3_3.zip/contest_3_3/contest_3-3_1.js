// File: contest_3-3_1.js

// First entry
function yourname_3d_contest_0() {
}

clear_all();
yourname_3d_contest_0();
