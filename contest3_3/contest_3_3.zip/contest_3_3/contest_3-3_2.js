// File: contest_3-3_2.js
	        
// Second entry
function yourname_3d_contest_1() {
}

clear_all();
yourname_3d_contest_1();
