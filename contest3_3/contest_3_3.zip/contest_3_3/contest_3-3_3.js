// File: contest_3-3_3.js
	        
// Third entry
function yourname_3d_contest_2() {
}

clear_all();
yourname_3d_contest_2();
